For instructions on installing this modpack, refer to https://wiki.minecrafttransitrailway.com/mtr_letsplay:modpack .

如果你不知道怎么安装这个整合包，请打开 https://wiki.minecrafttransitrailway.com/zh:mtr_letsplay:modpack 并阅读上面的指引。
